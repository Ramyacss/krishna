<?php

namespace Drupal\searchcon\Controller;
use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\JsonResponse;//
use Drupal\taxonomy\Entity\Term;//
use Drupal\Core\Url;
use Drupal\Core\Entity;
use Drupal\Core\Render\RendererInterface;


class SearchconController {

public function listSearch($val){

	 
   $query = \Drupal::entityQuery('node');
    $query->condition('field_zipcode', $val);
   // $query->condition('field_taxtype', $type);
    $entity_ids = $query->execute();
     $nodes=\Drupal\node\Entity\Node::loadMultiple($entity_ids);

     foreach ($nodes as $node) {
     	//echo "<pre>";
     	//print_r($node);  
	       $address = $node->field_addres->value;
	       $name = $node->field_name1->value;
	       $taxType = $node->field_taxtype->target_id;
	       $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($node->field_taxtype->target_id);//

	       $tax = $term->label();
	    // $address = $node->get('field_addres')->getValue(); 
     }
    
     //return \Drupal::service('renderer')->render($node);
     //drupal_render($node);
     $str = "Name=".$name ."<br> address=".$address ."<br> taxType=".$tax;
      return array(
      '#markup' =>$str,
       //'taxType' => $node->label(),//
    );




  
}
}

