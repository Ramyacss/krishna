<?php
namespace Drupal\searchcon\Plugin\Block;
use Drupal\taxonomy\Entity\Term;   
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Block\BlockPluginInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\JsonResponse;//
use Drupal\Core\Render\RendererInterface;
use Drupal\Core\Link;

    /**
     * Provides a 'SearchconExampleBlock' block.
     *
     * @Block(
     *   id = "searchcon_example_block",
     *   admin_label = @Translation("Example block"),
     *   category = @Translation("Custom example block")
     * )
    */
    class SearchconExampleBlock extends BlockBase {

     /**
      * {@inheritdoc}
     */
    


public function build() {


$vid = 'type';
$terms =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid);
foreach ($terms as $term) {
 $term_data[] = array(
  "id" => $term->tid,
  "name" => $term->name
 );

 $url = Url::fromRoute('entity.taxonomy_term.canonical', ['taxonomy_term' => $term->tid]);
 $link = Link::fromTextAndUrl($term->name, $url);
 $link = $link->toRenderable();
 $output .='<li>'.render($link).'</li>';

//  $link = [
//   '#type' => 'link',
//   '#title' => $term->name,
//   // Passing in 'language' key as the third option is preferable here so that a language-dependent alias can be found.
//   '#url' => Url::fromEntityUri('entity.taxonomy_term.canonical', ['taxonomy_term' => $term->tid])
// ];

// echo $link;
}

//print_r($output);
//print_r($term_data);die;

 // $query = \Drupal::entityQuery('node');
 //    //$query->condition('field_zipcode', $val);
 //   // $query->condition('field_taxtype', $type);
 //    $entity_ids = $query->execute();
 //    $nodes=\Drupal\node\Entity\Node::loadMultiple($entity_ids);
     

 //     foreach ($nodes as $node) {
 //      //echo "<pre>";
 //      //print_r($node);  
 //         //$address = $node->field_addres->value;
 //         //$name = $node->field_name1->value;
 //         $taxType = $node->field_taxtype->target_id;
         

 //         //$tax = $taxType->label();
 //      // $address = $node->get('field_addres')->getValue(); 
 //     }
 //    $str = "taxType=".$taxType;
    $build = [];
    $build['#markup'] = $output;


return $build;
    //return(
  //'#markup' => $this->configuration['default_LinkA_url'],
  //'#markup' => $this->configuration['default_LinkB_url'],
    //);
    

    /* public function build() {

       $form = \Drupal::formBuilder()->getForm('Drupal\searchcon\Form\SearchForm');

       return $form;*/
     }
   }