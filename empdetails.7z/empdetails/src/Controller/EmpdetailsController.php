<?php
namespace Drupal\empdetails\Controller;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
class EmpdetailsController {
public function empdetails() {
   $header_row = array(
    'id' => t('Id'),
    'name' => t('Name'),
    'phnno' => t('Phnno'),
    'email' => t('Email'),
    'age' => t('Age'),
    'gender' => t('Gender'),
    'jobtitle' => t('Jobtitle'),
    'dept' => t('Dept'),
    'address' => t('Address'),
    'zipcode' => t('Zipcode'),
    'state' => t('state'),
    );

    $connection = \Drupal::database();
	$query = $connection->select('empdetails','employee')
    ->fields('employee', ['id','name','phnno','email','age','gender','jobtitle','dept','address','zipcode','state']);
    $result = $query->execute()->fetchAll();
    $rows=array();
    foreach ($result as $rec) {  //collect all elements of an array
        $edit   = Url::fromUserInput('/empform?num='.$rec->id);
        $delete   = Url::fromUserInput('/delete?num='.$rec->id);
    	 $rows[] = array(   
            'id' => $rec->id,
            'name' => $rec->name,
            'phnno' => $rec->phnno,
            'email' => $rec->email,
            'age' => $rec->age, 
            'gender' => $rec->gender,
            'jobtitle' => $rec->jobtitle,
            'dept'=> $rec->dept,
            'address' => $rec->address,
            'zipcode' => $rec->zipcode,
            'state' => $rec->state,
            \Drupal::l('Edit', $edit),
            \Drupal::l('Delete', $delete),
            );
        }

        $form['table'] = [
            '#type' => 'table',
            '#header' => $header_row,
            '#rows' => $rows,
        ];  
        return $form;   
    }
 public function deleteEmpdetails() {
 $connection = \Drupal::database();
 $deletequery = $connection->delete('empdetails')
        ->condition('id', $_GET['num'])
        ->execute();
         return array(
                '#title' => 'Yes!',
                '#markup' => 'Your Empdetails Successfully Deleted',
            );

    }

}

?>