<?php
namespace Drupal\empdetails\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Database;
class EmpForm extends FormBase{

	public function getFormId(){
	 	return 'emp_form';
	}
    public function buildForm(array $form, FormStateInterface $form_state){

 		$connection = \Drupal::database();
 	    $record = array();

	    if (isset($_GET['num'])) {
	        $connection = \Drupal::database();
			$query = $connection->select('empdetails','employee')
			->condition('id', $_GET['num'])
		    ->fields('employee', ['id','name','phnno','email','age','gender','jobtitle','dept','address','zipcode']);
		    $record = $query->execute()->fetchAssoc();
	    }
$form['employee_name']=array(
		'#type' => 'textfield',
		'#title' => t('Employee Name'),
	'#required' => TRUE,
		'#default_value' => (isset($record['name']) && $_GET['num']) ? $record['name']:'',
		);	
$form['phnno']=array(
		'#type' => 'textfield',
		'#title' => t('Mobile'),
		'#required' => TRUE,
		'#default_value' => (isset($record['phnno']) && $_GET['num']) ? $record['phnno']:'',
		);
$form['employee_email']=array(
		'#type' => 'textfield',
	'#title' => t('Email Id'),
		'#required' => TRUE,
		'#default_value' => (isset($record['email']) && $_GET['num']) ? $record['email']:'',
		);
$form['employee_age']=array(
		'#type' => 'textfield',
		'#title' => t('Age'),
		'#required' => TRUE,
		'#default_value' => (isset($record['age']) && $_GET['num']) ? $record['age']:'',
		);
$form['gender']=array(
		'#type' => 'select',
		'#title' => t('Gender'),
		'#options' => array(
		 'Female' => t('Female'),
		 'Male' => t('Male'),
		'#default_value' => (isset($record['gender']) && $_GET['num']) ? $record['gender']:'',
		),
		);
$form['jobtitle']=array(
		'#type' => 'textfield',
	'#title' => t('Job Title'),
		'#required' => TRUE,
		'#default_value' => (isset($record['jobtitle']) && $_GET['num']) ? $record['jobtitle']:'',
		);
$form['dept']=array(
		'#type' => 'textfield',
	'#title' => t('Department'),
	'#required' => TRUE,
		'#default_value' => (isset($record['dept']) && $_GET['num']) ? $record['dept']:'',
		);
	
$form['address']=array(
		'#type' => 'textarea',
		'#title' => t('Address'),
		'#required' => TRUE,
		'#default_value' => (isset($record['address']) && $_GET['num']) ? $record['address']:'',
		);
$form['zipcode']=array(
		'#type' => 'textfield',
		'#title' => t('Zipcode'),
		'#required' => TRUE,
		'#default_value' => (isset($record['zipcode']) && $_GET['num']) ? $record['zipcode']:'',

		);
$form['state']=array(
        '#type'=>'select',
        '#title'=>t('state'),
        '#options'=>array('Hyderabad' => 'Hyderabad','Bangalore' => 'Bangalore','Chennai' => 'Chennai','Kerla' => 'Kerla'),
	    '#required' => TRUE,
	    '#default_value' => (isset($record['state']) && $_GET['num']) ? $record['state']:'',
      );
$form['submit']=array(
		'#type'=>'submit',
		'#value'=> $this->t('Submit'),
		);
    return $form;

	}
	public function submitForm(array &$form, FormStateInterface $form_state) {
    	$values = $form_state->getValues();
    	$employee_name = $values["employee_name"];
    	$employee_phnno = $values["phnno"];
    	$employee_email = $values["employee_email"];
    	$employee_age = $values["employee_age"];
    	$employee_gender = $values["gender"];
    	$job_title = $values["jobtitle"];
    	$employee_dept = $values["dept"];
        $employee_address = $values["address"];
    	$employee_zipcode = $values["zipcode"];
    	$employee_state = $values["state"];

   		if($_GET['num']){

	   		$fields=array('name'=>"$employee_name",'phnno'=>"$employee_phnno",'email'=>"$employee_email",'age'=>"$employee_age",'gender'=>"$employee_gender",'jobtitle'=>"$job_title",'dept'=>"$employee_dept",'address'=>"$employee_address",'zipcode'=>"$employee_zipcode",'state'=>"$employee_state"); 
			\Drupal::database()
			->update('empdetails')
			->condition('id',$_GET['num'])
			->fields($fields)
			->execute();
   		}
   		else{
			$fields=array('name'=>"$employee_name",'phnno'=>"$employee_phnno",'email'=>"$employee_email",'age'=>"$employee_age",'gender'=>"$employee_gender",'jobtitle'=>"$job_title",'dept'=>"$employee_dept",'address'=>"$employee_address",'zipcode'=>"$employee_zipcode",'state'=>"$employee_state"); 
			\Drupal::database()
			->insert('empdetails')
			->fields($fields)
			->execute();
		}

		$url = Url::fromRoute('empdetails.display');
		$form_state->setRedirectUrl($url);//nav to that root
		
		
   }

}

?>