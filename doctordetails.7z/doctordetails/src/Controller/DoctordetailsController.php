<?php
namespace Drupal\doctordetails\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;//
use Drupal\taxonomy\Entity\Term;//  
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Entity;
class DoctordetailsController {
public function doctordetails() {
   $header_row = array(
    'id' => t('Id'),
    'first_name' => t('First_name'),
    'laste_name' => t('Last_name'),
    'degree' => t('Degree'),
    'email' => t('Email'),
    'phnno' => t('Phnno'),
    'city' => t('City'),
    'specialty' => t('Specialty'),
    );

    $connection = \Drupal::database();
	$query = $connection->select('docdetails','doctor')
    ->fields('doctor', ['id','first_name','last_name','degree','email','phnno','city','specialty']);
    $result = $query->execute()->fetchAll();
    $rows=array();
    foreach ($result as $rec) {  //collect all elements of an array
        $edit   = Url::fromUserInput('/docform?num='.$rec->id);
        $delete   = Url::fromUserInput('/delete?num='.$rec->id);
       
        $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($rec->city);
        
        //  echo $value;
        
        //break; //return title of term
  
    	 $rows[] = array(   
            'id' => $rec->id,
            'first name' => $rec->first_name,
            'last name' => $rec->last_name,
            'degree' => $rec->degree,
            'email' => $rec->email,
            'phnno' => $rec->phnno,
            'city' => $term->label(),
            'specialty' => $rec->specialty,
            \Drupal::l('Edit', $edit),
            \Drupal::l('Delete', $delete),
            );
    
}
        $form['table'] = [
            '#type' => 'table',
            '#header' => $header_row,
            '#rows' => $rows,
        ];  
        return $form;   
    }
 public function deleteDocdetails() {
 $connection = \Drupal::database();
 $deletequery = $connection->delete('docdetails')
        ->condition('id', $_GET['num'])
        ->execute();
         return array(
                '#title' => 'Yes!',
                '#markup' => 'Your Doctordetails Successfully Deleted',
            );

    }

}

?>