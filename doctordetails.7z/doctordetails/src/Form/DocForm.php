<?php
namespace Drupal\doctordetails\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Database;

class DocForm extends FormBase{

	public function getFormId(){
	 	return 'doc_form';
	}
    public function buildForm(array $form, FormStateInterface $form_state){

 		$connection = \Drupal::database();
 	    $record = array();

	    if (isset($_GET['num'])) {
	        $connection = \Drupal::database();
			$query = $connection->select('docdetails','doctor')
			->condition('id', $_GET['num'])
		    ->fields('doctor',  ['id','first_name','last_name','degree','email','phnno','city','specialty']);
		    $record = $query->execute()->fetchAssoc();
			}
			$form['fname']=array(
					'#type' => 'textfield',
					'#title' => t('First Name'),
				'#required' => TRUE,
					'#default_value' => (isset($record['first_name']) && $_GET['num']) ? $record['first_name']:'',
					);	
			$form['lname']=array(
					'#type' => 'textfield',
					'#title' => t('Last Name'),
				'#required' => TRUE,
					'#default_value' => (isset($record['last_name']) && $_GET['num']) ? $record['last_name']:'',
					);	
			$form['degree']=array(
					'#type' => 'textfield',
					'#title' => t('degree'),
				'#required' => TRUE,
					'#default_value' => (isset($record['degree']) && $_GET['num']) ? $record['degree']:'',
					);	
			$form['email']=array(
					'#type' => 'textfield',
				'#title' => t('Email Id'),
					'#required' => TRUE,
					'#default_value' => (isset($record['email']) && $_GET['num']) ? $record['email']:'',
					);
			$form['phnno']=array(
					'#type' => 'textfield',
					'#title' => t('Mobile'),
					'#required' => TRUE,
					'#default_value' => (isset($record['phnno']) && $_GET['num']) ? $record['phnno']:'',
					);
$form['city'] = [
  '#type' => 'entity_autocomplete',
  '#target_type' => 'taxonomy_term',
  '#title' => 'city',
];

					
	/*	$form['specialty'] = [
  '#type' => 'entity_autocomplete',
  '#target_type' => 'taxonomy_term',
  '#title' => 'specialty',
];







	$form['city']=array(
			        '#type'=>'select',
			        '#title'=>t('city'),
			        '#options'=>array('Hyderabad' => 'Hyderabad','Bangalore' => 'Bangalore','Chennai' => 'Chennai','Kerla' => 'Kerla'),
				    '#required' => TRUE,
				    '#default_value' => (isset($record['city']) && $_GET['num']) ? $record['city']:'',
			      );*/
			$form['specialty']=array(
			        '#type'=>'select',
			        '#title'=>t('specialty'),
			        '#options'=>array('Allergists' => 'Allergists','Endocrinologists' => 'Endocrinologists','Cardiologists' => 'Cardiologists','Dermatologists' => 'Dermatologists'),
				    '#required' => TRUE,
				    '#default_value' => (isset($record['city']) && $_GET['num']) ? $record['city']:'',
			      );
			$form['submit']=array(
					'#type'=>'submit',
					'#value'=> $this->t('Submit'),
					);
			    return $form;

	}
	public function submitForm(array &$form, FormStateInterface $form_state) {
    	$values = $form_state->getValues();
    	$fname = $values["fname"];
    	$lname = $values["lname"];
    	$degree = $values["degree"];
    	$email = $values["email"];
    	$phnno = $values["phnno"];
    	$city = $values["city"];
        $specialty = $values["specialty"];
   		if($_GET['num']){

	   		$fields=array('first_name'=>"$fname",'last_name'=>"$lname",'degree'=>"$degree",'email'=>"$email",'phnno'=>"$phnno",'city'=>"$city",'specialty'=>"$specialty"); 
			\Drupal::database()
			->update('docdetails')
			->condition('id',$_GET['num'])
			->fields($fields)
			->execute();
   		}
   		else{
			$fields=array('first_name'=>"$fname",'last_name'=>"$lname",'degree'=>"$degree",'email'=>"$email",'phnno'=>"$phnno",'city'=>"$city",'specialty'=>"$specialty"); 
			\Drupal::database()
			->insert('docdetails')
			->fields($fields)
			->execute();
		}

		$url = Url::fromRoute('doctordetails.displays');
		$form_state->setRedirectUrl($url);//nav to that root
		
		
   }

}

?>